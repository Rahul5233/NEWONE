package com.blackberry.workspaces.sdk.examples;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;

    public class WorkspacesExample {
    private ObjectMapper mapper;
    private String authToken;
    private String serverURL;

    public WorkspacesExample(String authToken, String serverURL)
    {
        //an auth token(beginning with 'expires=") for use in an auth header 
        this.authToken = authToken;

        //This url should begin with http:// or https:// and end with a /
        this.serverURL = serverURL;

        mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /*
     * Example to create a room (workspace).
     */
    public Room createRoom(String name, String description, List<String> administrators) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getCreateRoomJsonBody(name, description, administrators);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/create");

        return mapper.readValue(postRequest, Room.class);
    }

    /*
     * Example to delete a room (workspace).
     */
    public boolean deleteRoom(boolean isPermanent, int roomId) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException,IOException
    {
        String JSONbody = getDeleteRoomJsonBody(isPermanent, roomId);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/delete");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to edit a room (workspace).
     */
    public Room editRoom(String roomId,String name, String description, boolean renameIfExists, boolean isPersonal, boolean shouldUpdatePersonal) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getEditRoomJsonBody(name, description, renameIfExists, isPersonal, shouldUpdatePersonal);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/" + roomId +"/edit");

        return mapper.readValue(postRequest, Room.class);
    }

    /*
     * Example to get a room (workspace) info.
     */
    public WorkspaceInfo infoRoom(String roomId) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String postRequest = sendPOSTRequest("api/rooms/" + roomId +"/info");

        return mapper.readValue(postRequest, WorkspaceInfo.class);
    }

    /*
     * Example to list all the virtual data rooms of the current user.
     */
    public RoomList listRooms() throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String getRequest = sendGETRequest("api/rooms");

        return mapper.readValue(getRequest, RoomList.class);
    }

    /*
     * Example to gets the tree of all folders and subfolders in a specified workspace.
     */
    public Folder getFolderTree(String roomId) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String getRequest = sendGETRequest("api/rooms/"+roomId+"/folders");

        return mapper.readValue(getRequest, Folder.class);
    }

    /*
     * Example to get URL link to a workspace.
     */
    public RoomLinks getRoomLinks(String roomId) throws JsonParseException, JsonMappingException, HttpException, IOException
    {
        String getRequest = sendPOSTRequest("api/rooms/"+roomId+"/links");

        return mapper.readValue(getRequest, RoomLinks.class);
    }

    /*
     * Example to rename a folder within a workspace using folderGUID(it can also be done using either folderId or path)
     */
    public String renameFolder(String roomId, String folderGuid ,String newFolderName) throws JsonParseException, JsonMappingException, HttpException, IOException
    {
        String JSONbody = getRenameFolderJsonBody(folderGuid, newFolderName);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/"+roomId+"/folders/rename");

        return postRequest;
     }

    /*
     * Example to move folders in a room (workspace).
     */
    public boolean moveFolders(String roomId, String currentPath, String newPath) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getMoveFolderJsonBody(currentPath, newPath);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/" + roomId +"/folders/move");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to invite groups to a room (workspace).
     */
    public boolean inviteGroup(String roomId, String emailSubject, String emailMessage, Set<String> groupNames, Set<String> additionalEmails) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getInviteJsonBody(emailSubject, emailMessage, groupNames, additionalEmails);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/" + roomId +"/invite");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to add members to a room (workspace).
     */
    public String addMembers(String roomId, String address, String  entityType, boolean isUsersDefaultEntity, boolean downloadOriginal, String usersRole) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getAddRoomMembers(address, entityType, isUsersDefaultEntity, downloadOriginal, usersRole);
        String postRequest = sendPOSTRequest(JSONbody, "api/rooms/" + roomId +"/members/add");

        return postRequest;
    }

    private String getCreateRoomJsonBody(String name, String description, List<String> administrators) throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String , Object> createRoomJsonMap = new HashMap<String , Object>();

        createRoomJsonMap.put("name", name);
        createRoomJsonMap.put("description", description);
        createRoomJsonMap.put("administrators", administrators);

        return mapper.writeValueAsString(createRoomJsonMap);
    }

    private String getEditRoomJsonBody(String name, String description, boolean renameIfExists, boolean isPersonal, boolean shouldUpdatePersonal) throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String , Object> editRoomJsonMap = new HashMap<String , Object>();

        editRoomJsonMap.put("name", name);
        editRoomJsonMap.put("description", description);
        editRoomJsonMap.put("renameIfExists", renameIfExists);
        editRoomJsonMap.put("isPersonal", isPersonal);
        editRoomJsonMap.put("shouldUpdatePersonal", shouldUpdatePersonal);

        return mapper.writeValueAsString(editRoomJsonMap);
    }

    private String getDeleteRoomJsonBody(boolean isPermanent, int roomId) throws JsonGenerationException, JsonMappingException, IOException
    {
         HashMap<String , Object> deleteRoomJsonMap = new HashMap<String , Object>();

         deleteRoomJsonMap.put("isPermanent", isPermanent);
         deleteRoomJsonMap.put("roomId", roomId);

         return mapper.writeValueAsString(deleteRoomJsonMap);
    }

    private String getRenameFolderJsonBody(String folderGuid ,String newFolderName) throws JsonProcessingException
    {
        HashMap<String , Object> renameFolderJsonMap = new HashMap<String , Object>();

        renameFolderJsonMap.put("folderGuid", folderGuid);
        renameFolderJsonMap.put("newFolderName", newFolderName);

        return mapper.writeValueAsString(renameFolderJsonMap);
    }

    private String getMoveFolderJsonBody(String currentPath, String newPath) throws JsonProcessingException
    {
        HashMap<String , Object> moveFolderJsonMap = new HashMap<String , Object>();

        moveFolderJsonMap.put("currentPath", currentPath);
        moveFolderJsonMap.put("newPath", newPath);

        return mapper.writeValueAsString(moveFolderJsonMap);
    }

    private String getInviteJsonBody(String emailSubject, String emailMessage, Set<String> groupNames, Set<String> additionalEmails) throws JsonProcessingException
    {
        HashMap<String , Object> inviteJsonMap = new HashMap<String , Object>();

        inviteJsonMap.put("emailSubject", emailSubject);
        inviteJsonMap.put("emailMessage", emailMessage);
        inviteJsonMap.put("groupNames", groupNames);
        inviteJsonMap.put("additionalEmails", additionalEmails);

        return mapper.writeValueAsString(inviteJsonMap);
    }

    private String getAddRoomMembers(String address, String entityType, boolean isUsersDefaultEntity, boolean downloadOriginal, String usersRole) throws JsonProcessingException
    {
        HashMap<String , Object> addRoomMembersJsonMap = new HashMap<String , Object>();
        HashMap<String , Object> usersPermissionsJsonMap = new HashMap<String , Object>();
        HashMap<String , Object> permittedEntityJsonMap = new HashMap<String , Object>();
        HashMap<String , Object> addRoomMemberJsonMap = new HashMap<String , Object>();

        //only downloadOriginal is used for this example code.Flag indicating that downloading protected document is allowed.
        usersPermissionsJsonMap.put("downloadOriginal", downloadOriginal);

        permittedEntityJsonMap.put("address", address);
        permittedEntityJsonMap.put("entityType",entityType);
        addRoomMemberJsonMap.put("permittedEntity", permittedEntityJsonMap);

        addRoomMembersJsonMap.put("usersPermissions", usersPermissionsJsonMap);
        addRoomMembersJsonMap.put("newMembers", addRoomMemberJsonMap);
        addRoomMembersJsonMap.put("usersRole", usersRole);
        addRoomMembersJsonMap.put("isUsersDefaultEntity", isUsersDefaultEntity);

        return mapper.writeValueAsString(addRoomMembersJsonMap);
    }
    private String sendGETRequest(String watchDoxApiURL) throws HttpException, IOException
    {
        HttpClient client = new HttpClient();
        StringBuilder urlBuilder = new StringBuilder(serverURL).append(watchDoxApiURL);

        GetMethod getMethod = new GetMethod(urlBuilder.toString());
        getMethod.addRequestHeader("Content-Type", "application/json");
        getMethod.addRequestHeader("Authorization", "Bearer " + authToken);

        client.executeMethod(getMethod);
        System.out.println(getMethod.getStatusLine());

        return getMethod.getResponseBodyAsString();
    }

    private String sendPOSTRequest(String watchDoxApiURL) throws HttpException, IOException
    {
       return sendPOSTRequest("", watchDoxApiURL);
    }

    private String sendPOSTRequest(String JSONbody, String watchDoxApiURL) throws HttpException, IOException
    {
        HttpClient client = new HttpClient();
        StringBuilder urlBuilder = new StringBuilder(serverURL).append(watchDoxApiURL);

        PostMethod postMethod = new PostMethod(urlBuilder.toString());
        postMethod.addRequestHeader("Content-Type", "application/json");
        postMethod.addRequestHeader("Authorization", "Bearer " + authToken);

        StringRequestEntity requestEntity = new StringRequestEntity(JSONbody, "application/json", "UTF-8");
        postMethod.setRequestEntity(requestEntity);

        client.executeMethod(postMethod);
        System.out.println(postMethod.getStatusLine());

        return postMethod.getResponseBodyAsString();
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Base
    {
        public String uuid;

        //Description to the newly created (Renamed) room(workspace)
        public String description = "";

        //Name to the newly created (Renamed) room(workspace)
        public String name;

        //Room (Workspace) id
        public String id;
        public String objType;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Room extends Base
    {
        public PersonalRoomJson creator;
        public Date creationDate;

        //Link to the newly created (Renamed) room(workspace)
        public String hyperlink;

        //The user's role in the workspace.
        public String accessLevel;
        public String workspaceType = "LOCAL_WORKSPACE";
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class WorkspaceInfo extends Room
    {
        public Set<String> actualAdmins;
        public String deletedItemsCount;
        public Date lastFileModifiedDate;
        public long totalFilesSize;
        public int totalFoldersCount;
        public int totalFilesCount;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RoomList
    {
        public List<Room> items ;
        public String total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Folder extends Base
    {
        public String folderRole;
        public String fullPath;
        public List<Folder> subFolders = new ArrayList<Folder>();
        public boolean hasSubfolders;
        public Date updateDate;
        public boolean isPermsInherited;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RoomLinks
    {
        public String trackActivityLink = "";
        public String quickShareLink = "";
        public String directLink = "";
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BulkOperationResult
    {
        //Indicates whether all operations completed successfully. Possible values: [PARTIAL, NONE, FULL]. 
        public String success;

        public boolean isOperationsSuccessful()
        {
            if(success.contentEquals("FULL") || success.contentEquals("PARTIAL"))
            {
              return true;
          }
            else
            {
              return false;
            }
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PersonalRoomJson
    {
        public String address;
        public String name;
    }
}
