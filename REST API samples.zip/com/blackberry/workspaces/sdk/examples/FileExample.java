package com.blackberry.workspaces.sdk.examples;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileExample
{
    private String auth;
    private String serverUrl;
    private ObjectMapper mapper;

    /*
     * Auth is the authorization token, serverURL is the server URL in the form of http://server.com/ or https://server.com/.
     * There must be a trailing slash.
     */
    public FileExample(String auth, String serverURL)
    {
        this.serverUrl = serverURL;
        this.auth = auth;

        mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /*
     * Example to create and upload a new document. Document must be submitted after this.
     */
    public String createDocument(String roomId, String filename)
            throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        printStatus("Creating a document...");

        // NOTE: no body JSON
        String url = "api/3.0/rooms/" + roomId + "/documents/upload";
        String result = sendFile(auth, url, new File(filename));

        return mapper.readValue(result, Guid.class).guid;
    }

    /*
     * Example to submit a previously uploaded document to a workspace. Use the guid returned by the create method.
     * The guid returned by the submit should be used for all future actions on this document.
     */
    public SubmitDocumentResultItemList submitDocument(String roomId, String documentGuid)
            throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        printStatus("Submitting document...");

        String bodyJson = getSubmitDocumentJsonBody(documentGuid);
        String url = "api/3.0/rooms/" + roomId + "/documents/submit";
        String result = sendRequest(auth, url, bodyJson);

        return mapper.readValue(result, SubmitDocumentResultItemList.class);
    }

    /*
     * Example for renaming a document.
     */
    public String renameDocument(String roomId, String documentGuid, String newName)
            throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        printStatus("Renaming document...");

        String bodyJson = getRenameDocumentJsonBody(newName);
        String url = "api/3.0/rooms/" + roomId + "/documents/" + documentGuid + "/rename";
        String result = sendRequest(auth, url, bodyJson);

        return result;
    }

    /*
     * Example to list all documents in a room.
     */
    public DocumentList listDocuments(String roomId)
            throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        printStatus("List documents...");

        String bodyJson = "{}";
        String url = "api/3.0/rooms/" + roomId + "/documents/list";
        String result = sendRequest(auth, url, bodyJson);

        return mapper.readValue(result, DocumentList.class);
    }

    /*
     * Example to delete a single document. Multiple documents could be deleted, but only one is done here.
     */
    public boolean deleteDocument(boolean isPermanent, String roomId, String documentGuid)
            throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        printStatus("Deleting document...");

        String bodyJson = getDeleteDocumentJsonBody(isPermanent, documentGuid);
        String url = "api/3.0/rooms/" + roomId + "/documents/delete";
        String result = sendRequest(auth, url, bodyJson);

        return mapper.readValue(result, BulkOperationResult.class).fullSuccess;
    }

    /*
     * Perform a basic POST request
     */
    private String sendRequest(String auth, String routeUrl, String bodyJson) throws HttpException, IOException
    {
        PostMethod postMethod = new PostMethod(serverUrl + routeUrl);
        postMethod.addRequestHeader("Content-Type", "application/json");
        postMethod.addRequestHeader("Authorization", "Bearer " + auth);

        StringRequestEntity requestEntity = new StringRequestEntity(bodyJson, "application/json", "UTF-8");
        postMethod.setRequestEntity(requestEntity);
        System.out.println("Request body: " + bodyJson);

        HttpClient client = new HttpClient();
        client.executeMethod(postMethod);

        String result = postMethod.getResponseBodyAsString();
        System.out.println("Response: " + result);
        System.out.println();

        return result;
    }

    /*
     * Perform a multipart POST request, which uploads a file
     */
    private String sendFile(String auth, String routeUrl, File file) throws HttpException, IOException
    {
        PostMethod postMethod = new PostMethod(serverUrl + routeUrl);
        postMethod.addRequestHeader("Authorization", "Bearer " + auth);
        postMethod.setRequestHeader("Connection", "keep-alive");

        List<Part> parts = new ArrayList<Part>();
        parts.add(new StringPart("documentName", file.getName(), "UTF-8"));
        parts.add(new FilePart("data", file));

        MultipartRequestEntity multipartRequest =
                new MultipartRequestEntity(parts.toArray(new Part[] {}), postMethod.getParams());
        postMethod.setRequestEntity(multipartRequest);

        HttpClient client = new HttpClient();
        client.executeMethod(postMethod);

        String result = postMethod.getResponseBodyAsString();
        System.out.println("Response: " + result);
        System.out.println();

        return result;
    }

    private String getSubmitDocumentJsonBody(String documentGuid)
            throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String, Object> submitDocumentJsonMap = new HashMap<String, Object>();
        HashSet<String> documentGuidsSet = new HashSet<String>();
        documentGuidsSet.add(documentGuid);
        submitDocumentJsonMap.put("documentGuids", documentGuidsSet);

        return mapper.writeValueAsString(submitDocumentJsonMap);
    }

    private String getDeleteDocumentJsonBody(boolean isPermanent, String documentGuid)
            throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String, Object> deleteRoomJsonMap = new HashMap<String, Object>();
        HashSet<String> documentGuidsSet = new HashSet<String>();
        documentGuidsSet.add(documentGuid);
        deleteRoomJsonMap.put("isPermanent", isPermanent);
        deleteRoomJsonMap.put("documentGuids", documentGuidsSet);

        return mapper.writeValueAsString(deleteRoomJsonMap);
    }

    private String getRenameDocumentJsonBody(String newName) throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String, Object> renameDocumentJsonMap = new HashMap<String, Object>();
        renameDocumentJsonMap.put("newFileName", newName);

        return mapper.writeValueAsString(renameDocumentJsonMap);
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Guid
    {
        public String guid;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SubmitDocumentResultItemList
    {
        public List<SubmitDocumentResult> items = new ArrayList<SubmitDocumentResult>();
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SubmitDocumentResult
    {
        // Many other fields left out
        public String guid;
        public int id;
        public String name;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DocumentList
    {
        public String total;
        public List<Document> items;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Document
    {
        // Many other attributes are not shown here
        public String contentType;
        public String filename;
        public String guid;
        public String name;
        public String url;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BulkOperationResult
    {
        public boolean fullSuccess;
        public String success;
    }

    private void printStatus(final String message)
    {
        System.out.println();
        System.out.println(message);
        System.out.println("--------------------------------------------");
    }
}
