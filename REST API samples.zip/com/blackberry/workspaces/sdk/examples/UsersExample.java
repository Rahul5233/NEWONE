package com.blackberry.workspaces.sdk.examples;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;

public class UsersExample {
    private ObjectMapper mapper;
    private String authToken;
    private String serverURL;

    public UsersExample(String authToken, String serverURL)
    {
        //an auth token(beginning with 'expires=") for use in an auth header 
        this.authToken = authToken;

        //This url should begin with http:// or https:// and end with a /
        this.serverURL = serverURL;

        mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /*
     * Example to add a specific user.
     */
    public boolean addUser(String userEmail, Set<String> aliases, Set<String> roles, String friendlyName) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getAddUsersJsonBody(userEmail, aliases, roles, friendlyName);
        String postRequest = sendPOSTRequest(JSONbody, "api/organizations/users/add");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to edit a specific user.
     */
    public boolean editUser(String language, boolean sendNotifications, boolean updateSendNotifications, int timezoneOffset, boolean updateTimezoneOffset, String userName, boolean updateUserName) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, JsonProcessingException,IOException
    {
        String JSONbody = getEditUserJsonBody(language, sendNotifications, updateSendNotifications, timezoneOffset, updateTimezoneOffset, userName, updateUserName);
        String postRequest = sendPOSTRequest(JSONbody, "api/users/edit");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to remove users.
     */
    public boolean removeUsers(List<String> users) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getRemoveUserJsonBody(users);
        String postRequest = sendPOSTRequest(JSONbody, "api/organizations/users/delete");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    /*
     * Example to copy membership( of several users ) to another existing user.
     */
    public boolean copyMemebership(List<String> usersFrom, String userTo) throws JsonGenerationException, JsonMappingException, UnsupportedEncodingException, IOException
    {
        String JSONbody = getCopyMembershipJson(usersFrom, userTo);
        String postRequest = sendPOSTRequest(JSONbody, "api/organizations/users/memberships/copy");

        return mapper.readValue(postRequest, BulkOperationResult.class).isOperationsSuccessful();
    }

    private String getRemoveUserJsonBody(List<String> users) throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String , Object> removeUserJsonMap = new HashMap<String , Object>();

        removeUserJsonMap.put("forceAction", true);
        removeUserJsonMap.put("users", users);
        removeUserJsonMap.put("targetUser", "");

        return mapper.writeValueAsString(removeUserJsonMap);
    }

    private String getAddUsersJsonBody(String userEmail, Set<String> aliases, Set<String> roles, String userName) throws JsonGenerationException, JsonMappingException, IOException
    {
        HashMap<String , Object> userJsonMap = new HashMap<String , Object>();
        HashMap<String , Object> userDetailsJsonMap = new HashMap<String , Object>();
        HashMap<String , Object> usersJsonMap = new HashMap<String , Object>();

        userDetailsJsonMap.put("userName", userName);
        userDetailsJsonMap.put("aliases", aliases);
        userDetailsJsonMap.put("roles", roles);

        usersJsonMap.put("userDetails", userDetailsJsonMap);
        usersJsonMap.put("userEmail", userEmail);

        userJsonMap.put("users", usersJsonMap);
        userJsonMap.put("forceAction", true);

      return mapper.writeValueAsString(userJsonMap);
    }

    private String getEditUserJsonBody(String language, boolean sendNotifications, boolean updateSendNotifications, int timezoneOffset, boolean updateTimezoneOffset, String userName, boolean updateUserName) throws JsonProcessingException
    {
        HashMap<String , Object> editUserJsonMap = new HashMap<String , Object>();

        editUserJsonMap.put("language", language);
        editUserJsonMap.put("sendNotifications", sendNotifications);
        editUserJsonMap.put("updateSendNotifications", updateSendNotifications);
        editUserJsonMap.put("timezoneOffset", timezoneOffset);
        editUserJsonMap.put("updateTimezoneOffset", updateTimezoneOffset);
        editUserJsonMap.put("userName", userName);
        editUserJsonMap.put("updateUserName", updateUserName);

        return mapper.writeValueAsString(editUserJsonMap);
    }

    private String getCopyMembershipJson(List<String> usersFrom, String userTo) throws JsonProcessingException
    {
        HashMap<String , Object> copyMembershipJsonMap = new HashMap<String , Object>();

        copyMembershipJsonMap.put("usersFrom", usersFrom);
        copyMembershipJsonMap.put("userTo", userTo);
        copyMembershipJsonMap.put("forceAction", true);

        return mapper.writeValueAsString(copyMembershipJsonMap);
    }

    private String sendPOSTRequest(String JSONbody ,String watchDoxApiURL) throws HttpException, IOException
    {
        HttpClient client = new HttpClient();
        StringBuilder urlBuilder = new StringBuilder(serverURL).append(watchDoxApiURL);

        PostMethod postMethod = new PostMethod(urlBuilder.toString());
        postMethod.addRequestHeader("Content-Type", "application/json");
        postMethod.addRequestHeader("Authorization", "Bearer " + authToken);

        StringRequestEntity requestEntity = new StringRequestEntity(JSONbody, "application/json", "UTF-8");
        postMethod.setRequestEntity(requestEntity);

        client.executeMethod(postMethod);
        System.out.println(postMethod.getStatusLine());

        return postMethod.getResponseBodyAsString();
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BulkOperationResult
    {
        //Indicates whether all operations completed successfully. Possible values: [PARTIAL, NONE, FULL]. 
        public String success;

        public boolean isOperationsSuccessful()
        {
            if(success.contentEquals("FULL") || success.contentEquals("PARTIAL"))
            {
              return true;
          }
            else
            {
              return false;  
            }
        }
    }
}