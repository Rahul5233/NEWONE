package com.blackberry.workspaces.sdk.examples;

import java.io.IOException;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/*
 * This class represents an example of using OAuth authentication against a WatchDox
 * server(as opposed to the more traditional username/password authentication).
 * 
 * Watchdox OAuth lets users allow other applications to interact with their WatchDox
 * account without providing that other application their WatchDox authentication
 * credentials, and only for a time-limited basis. For example, a sales management application
 * can integrate WatchDox functionality to allow the controlled sharing of documents
 * via WatchDox, within the sales management app, without requiring users to provide their
 * WatchDox usernames and passwords to the sales management app.
 * 
 * Someone wishing to use WatchDox OAuth must register with them an obtain a client ID
 * and client secret that will be passed to WatchDox in order to obtain a WatchDox authentication
 * token.
 * 
 * The basic flow is:
 * 
 * 1. Make an unauthenticated call to WatchDox to get the authentication URI's.
 * 
 * 2. Direct the user to the WatchDox authenticationUri (e.g. via a redirect in
 * your own web app), passing the proper params as built in getOauthUri() below.
 * One of these params is the redirect URI in your app to which the user should be sent
 * after authenticating with WatchDox.
 * 
 * 3. When that redirect URI is serviced in your web app, a temporary token is
 * included on the URL that will be used to obtain a valid auth token.
 * 
 * 4. Make a call to the WatchDox tokenUri as built up in getAuthToken() to obtain
 * valid auth token, refresh token, and an expiration value for the auth token.
 * That auth token can be used to authenticate subsequent API calls to the
 * Watchdox server.
 * 
 * In this example, the Java Application class is used to open a mini-browser window
 * to the WatchDox authorization URI, allowing a user to authenticate against WatchDox,
 * and then be redirected to an URL from which the temporary token can be parsed. In a
 * live implementation, that would all be done using browser redirects in a web-based
 * application.
 * 
 */
@SuppressWarnings("restriction")
public class OauthAuthenticationExample extends Application
{
    private String baseServerUrl;
    private String clientId;
    private String clientSecret;
    private ObjectMapper mapper;
    private String authorizationUri;
    private String authCode = "";
    private String tokenUri;
    private String redirectUri;

    public void launchApp(String[] args)
    {
        if (args.length != 4)
        {
            System.out.println("Inadequate required arguments: server URL, client Id, client secret, redirect URL");
            System.exit(0);
        }

        // Call the superclass method to start the Application
        Application.launch(args); // this will kick off start() below

    }

    /**
     * Parses the params and then kicks off the process by opening a mini-browser window
     * 
     * @param primaryStage
     *            (passed in automatically)
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        Parameters parameters = getParameters();
        List<String> unnamedParameters = parameters.getUnnamed();

        // This url should begin with http:// or https:// and end with a /
        this.baseServerUrl = unnamedParameters.get(0);
        this.clientId = unnamedParameters.get(1);
        this.clientSecret = unnamedParameters.get(2);
        this.redirectUri = unnamedParameters.get(3);

        // Step #1 above:
        setAuthenticationUriVars();
        AuthenticationWindow authWindow = new AuthenticationWindow();
        authWindow.showAuthenticationWindow(primaryStage);
    }

    /**
     * Makes the call to WatchDox to get the URLs for getting the temporary code, plus the access token.
     * 
     * @throws HttpException
     *             i.e. network error
     * @throws IOException
     *             i.e. JSON parsing error
     */
    public void setAuthenticationUriVars() throws HttpException, IOException
    {
        HttpClient client = new HttpClient();
        mapper = new ObjectMapper();
        GetMethod getMethod = new GetMethod(baseServerUrl + "api/3.0/authentication/parameters");
        client.executeMethod(getMethod);
        AuthParamsResponseJson responseObject =
                mapper.readValue(getMethod.getResponseBodyAsString(), AuthParamsResponseJson.class);
        authorizationUri = responseObject.authorizationUri; // for the temporary code
        tokenUri = responseObject.accessTokenUri; // for the access token
    }

    /**
     * Opens a mini-browser to show the user the WatchDox login page.
     * It then sets a listener on the window so that after the user authenticates
     * with WatchDox and is redirected to a new URL that includes the temporary code, this
     * temporary code can be picked off the URL and used to obtain an access token.
     */
    private class AuthenticationWindow
    {

        public void showAuthenticationWindow(Stage primaryStage) throws Exception
        {

            StackPane root = new StackPane();
            String oauthUri = getOauthUri();

            WebView view = new WebView();
            WebEngine engine = view.getEngine();

            engine.load(oauthUri);
            root.getChildren().add(view);

            Scene scene = new Scene(root, 800, 600);
            primaryStage.setScene(scene);

            // Step #2 above:
            primaryStage.show();

            // Add a listener for changes in the worker state.
            engine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>()
            {
                @SuppressWarnings("rawtypes")
                @Override
                public void changed(ObservableValue ov, State oldState, State newState)
                {

                    // See if the worker state change is that it is running(i.e. being asked to go to a new location)
                    if (newState == Worker.State.RUNNING) // i.e. the location is changing
                    {
                        String newLocation = engine.getLocation();
                        if (newLocation.startsWith(redirectUri)) // we only care about redirection after WatchDox authentication
                        {
                            if (newLocation.contains("code="))
                            {
                                try
                                {
                                    // Step #3 above:
                                    getCodeFromURL(engine.getLocation());
                                    primaryStage.close();
                                }
                                catch (IOException e)
                                {
                                    System.out.println("Error in communication or data deserialization");
                                }
                            }
                            else
                            {
                                // For whatever reason, we arrived at the redirect location with no code.
                                primaryStage.close();
                            }
                        }
                    }

                }
            });

        }

    }

    /**
     * This method strips the temporary code off the redirect URL, per step 3 above.
     * 
     * https://www.redirectURL.com/?code=219e5a32-d74f-473a-91a4-fd74f95e091c&locale=en-us
     * 
     * @param url
     * @throws HttpException
     *             i.e. networking error
     * @throws IOException
     *             i.e. JSON parsing error
     */
    private void getCodeFromURL(String url) throws HttpException, IOException
    {
        int startOfCodeKey = url.indexOf("code=");
        int startOfCodeValue = startOfCodeKey + 5; // code=
        int endCode = url.indexOf("&", startOfCodeKey);
        authCode = url.substring(startOfCodeValue, endCode);

        // Step #4 above
        getAuthToken();
    }

    /**
     * Sends a request to the WatchDox tokenUri to obtain an access token, per step 4 above.
     * The access token can then be used to authenticate requests made to WatchDox by adding
     * it as an HTTP header like this:
     * 
     * Authorization: Bearer expires=1469129151&created=1469127251&user=XXXXXX...
     * 
     * using the exact string returned as the access_token member.
     * 
     * @throws HttpException
     *             i.e. networking error
     * @throws IOException
     *             i.e. JSON parsing error
     */
    private void getAuthToken() throws HttpException, IOException
    {
        HttpClient client = new HttpClient();
        mapper = new ObjectMapper();
        StringBuilder urlBuilder = new StringBuilder(tokenUri);
        urlBuilder.append("?client_id=" + clientId);
        urlBuilder.append("&client_secret=" + clientSecret);
        urlBuilder.append("&grant_type=authorization_code");
        urlBuilder.append("&code=" + authCode);
        urlBuilder.append("&redirect_uri=" + redirectUri);

        GetMethod getMethod = new GetMethod(urlBuilder.toString());
        client.executeMethod(getMethod);
        AuthTokenResponseJson responseObject = mapper.readValue(getMethod.getResponseBodyAsString(), AuthTokenResponseJson.class);
        System.out.println("refresh_token= " + responseObject.refresh_token);
        System.out.println("expires_in= " + responseObject.expires_in);
        System.out.println("access_token= " + responseObject.access_token);
    }

    private String getOauthUri()
    {
        StringBuilder builder = new StringBuilder(authorizationUri);
        builder.append("?response_type=code");
        builder.append("&client_id=" + clientId);
        builder.append("&locale=en_US");
        builder.append("&redirect_uri=" + redirectUri);
        return builder.toString();
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class AuthParamsResponseJson
    {
        /*
         * This inner class is used to take the JSON from the response body and return an object
         * that allows us to access just the authorization and toen access URI's.
         */

        @SuppressWarnings("unused")
        public AuthParamsResponseJson()
        {
            // required by Jackson
        }

        @JsonProperty("authorizationUri")
        public String authorizationUri;

        @JsonProperty("accessTokenUri")
        public String accessTokenUri;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class AuthTokenResponseJson
    {
        /*
         * This inner class is used to take the JSON from the response body and return an object
         * that allows us to access the 3 authentication params
         */

        @SuppressWarnings("unused")
        public AuthTokenResponseJson()
        {
            // required by Jackson
        }

        @JsonProperty("refresh_token")
        public String refresh_token;

        @JsonProperty("expires_in")
        public String expires_in;

        @JsonProperty("access_token")
        public String access_token;

    }
}
