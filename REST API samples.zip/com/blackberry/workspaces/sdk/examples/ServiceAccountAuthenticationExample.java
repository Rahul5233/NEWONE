package com.blackberry.workspaces.sdk.examples;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

/*
 * This class represents an example of using service account authentication with
 * WatchDox.
 * 
 * It assumes that you have already created a local keystore and a
 * WatchDox service account, and have copied the public key to the
 * service account.
 * 
 */

public class ServiceAccountAuthenticationExample
{

  private String issuer;
  private PrivateKey privateKey;

  /*
   * issuer - the WatchDox-generated ID associated with the service account that will be used
   * keystorePassword- the password set on the keystore when it was created
   * keystoreAlias - the alias set on the keytore when it was created
   * fqKeystorePath - the fully qualified path to the keystore, relative to the class file location
   * keystoreType- the type of keytore(e.g. jceks, jks, pkcs12, etc.)
   */
  public ServiceAccountAuthenticationExample(String issuer, String keystorePassword, String keystoreAlias, String fqKeystorePath,
      String keystoreType) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException
  {
    this.issuer = issuer;
    privateKey = getPrivateKey(keystorePassword, keystoreAlias, fqKeystorePath, keystoreType);
  }

  /*
   * Main method for driving the example.
   * Returns an auth token(beginning with 'expires=") for use in an auth header like this:
   * 
   * Authorization: Bearer expires=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
   */
  public String generateToken(String userEmail) throws UnrecoverableKeyException, KeyStoreException
  {
    Map<String, String> parameters = new HashMap<String, String>();
    parameters.put("user", userEmail);
    parameters.put("issuer", issuer);
    parameters.put("expires", String.valueOf(new Date().getTime() / 1000 + 1800));
    String data = null;
    String signature = null;
    try
    {
      data = encodeQueryParams(parameters);
      signature = createSignature(data);
    }
    catch (UnsupportedEncodingException e)
    {
      System.out.println("Error encountered: " + e);
    }

    return data + ":" + signature;
  }

  // A private helper method for URL-encoding the query params
  private String encodeQueryParams(Map<String, String> parameters) throws UnsupportedEncodingException
  {
    StringBuilder result = new StringBuilder();
    for (String paramName : parameters.keySet())
    {
      result.append(URLEncoder.encode(paramName, "UTF-8"));
      result.append("=");
      result.append(URLEncoder.encode(parameters.get(paramName), "UTF-8"));
      result.append("&");
    }
    return result.toString();
  }

  // A private helper method to create the encrypted token
  private String createSignature(String data)
  {
    String rVal = null;
    try
    {
      Signature signature = Signature.getInstance("SHA1withRSA"); // adjust as needed
      signature.initSign(privateKey);
      signature.update(data.getBytes());
      byte[] raw = signature.sign();
      rVal = DatatypeConverter.printBase64Binary(raw);
    }
    catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException e)
    {
      System.out.println("Error in generating encrypted portion of token: " + e);
    }

    return rVal;

  }

  // A private helper method to get and load the keystore from its file, then extract the private key.
  private PrivateKey getPrivateKey(String keystorePassword, String keystoreAlias, String fqKeystorePath, String keystoreType)
      throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException
  {
    KeyStore keystore = null;
    char[] pwdChar = keystorePassword.toCharArray();
    try (InputStream resourceAsStream = new FileInputStream(fqKeystorePath))
    {
      keystore = KeyStore.getInstance(keystoreType);
      keystore.load(resourceAsStream, pwdChar);
    }
    catch (Exception e)
    {
      throw new UnrecoverableKeyException("Error in reading keystore from file.  Ensure fully qualified path param is correct. ");
    }

    return (PrivateKey) keystore.getKey(keystoreAlias, keystorePassword.toCharArray());
  }

}
